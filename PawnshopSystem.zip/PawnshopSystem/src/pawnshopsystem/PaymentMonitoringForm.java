/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pawnshopsystem;
import java.awt.Component;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.DefaultCellEditor;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import javax.swing.JTable;
import java.util.Date;
import java.text.SimpleDateFormat;




/**
 *
 * @author Acer
 */
public class PaymentMonitoringForm extends javax.swing.JFrame {
    
    

    /**
     * Creates new form PaymentMonitoringForm
     */
    public PaymentMonitoringForm() {
        initComponents();
        loadTransactions();
    }
    private void loadTransactions() {
        DefaultTableModel model = new DefaultTableModel(new String[]{
    "ID", "Item ID", "Customer", "Item", "Amount", "Balance After", "Status", "Date", "Delete"
}, 0);


        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM payment_transactions ORDER BY payment_date DESC";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getInt("item_id"),
                    rs.getString("customer_name"),
                    rs.getString("item_name"),
                    rs.getDouble("payment_amount"),
                    rs.getDouble("balance_after"),
                    rs.getString("status"),
                    rs.getTimestamp("payment_date"),
                        "Delete"
                });
            }

            transactionTable.setModel(model);
            transactionTable.getColumn("Delete").setCellRenderer(new ButtonRenderer());
            transactionTable.getColumn("Delete").setCellEditor(new ButtonEditor(new JCheckBox()));

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load transactions: " + e.getMessage());
        }
    }
    
    public void deleteTransaction(int row) {
        int id = (int) transactionTable.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this transaction?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DBConnection.getConnection()) {
                String sql = "DELETE FROM payment_transactions WHERE id = ?";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setInt(1, id);
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Transaction deleted.");
                loadTransactions();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error deleting transaction: " + e.getMessage());
            }
        }
        
    }
    
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
            setBackground(java.awt.Color.RED);
            setForeground(java.awt.Color.WHITE);
        }

       public Component getTableCellRendererComponent(JTable table, Object value,
            boolean isSelected, boolean hasFocus, int row, int column) {
        setText((value == null) ? "Delete" : value.toString());
        return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private String label;
        private boolean clicked;
        private int row;

        public ButtonEditor(JCheckBox checkBox) {
        super(checkBox);
        button = new JButton();
        button.setOpaque(true);
        button.setBackground(java.awt.Color.RED);
        button.setForeground(java.awt.Color.WHITE);
        button.addActionListener(e -> {
            int confirmedRow = this.row;
            fireEditingStopped();
            if (confirmedRow >= 0) {
                deleteTransaction(confirmedRow);
            }
                });
    }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
        boolean isSelected, int row, int column) {
            this.row = row;
            this.label = (value == null) ? "Delete" : value.toString();
        button.setText(label);
        clicked = true;
            return button;
        }
        @Override
        public Object getCellEditorValue() {
        clicked = false;  
        return label;
    }
         @Override
        public boolean stopCellEditing() {
            clicked = false;
            return super.stopCellEditing();
        }
 }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        transactionTable = new javax.swing.JTable();
        backbtn = new javax.swing.JButton();
        searchbtn = new javax.swing.JButton();
        searchdateChooser = new com.toedter.calendar.JDateChooser();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Gloucester MT Extra Condensed", 1, 36)); // NOI18N
        jLabel2.setText("Payment Monitoring");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 40, -1, -1));

        transactionTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(transactionTable);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1096, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 522, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 160, 1110, 540));

        backbtn.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        backbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pawnshopsystem/balik.png"))); // NOI18N
        backbtn.setText("Back");
        backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbtnActionPerformed(evt);
            }
        });
        getContentPane().add(backbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 710, -1, -1));

        searchbtn.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        searchbtn.setText("Search:");
        searchbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchbtnActionPerformed(evt);
            }
        });
        getContentPane().add(searchbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, 120, 30));
        getContentPane().add(searchdateChooser, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 110, 170, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pawnshopsystem/bgbg.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-110, 10, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbtnActionPerformed
    Dashboard dashboard = new Dashboard();
    dashboard.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_backbtnActionPerformed

    private void searchbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchbtnActionPerformed
     Date selectedDate = searchdateChooser.getDate(); // JDateChooser component
    if (selectedDate == null) {
        loadTransactions(); // Load all if no date selected
    } else {
        String formattedDate = new SimpleDateFormat("yyyy-MM-dd").format(selectedDate);
        loadTransactionsByDate(formattedDate);
    }
} 
    private void loadTransactionsByDate(String dateStr) {
    DefaultTableModel model = new DefaultTableModel(new String[]{
        "ID", "Item ID", "Customer", "Item", "Amount", "Balance After", "Status", "Date", "Delete"
    }, 0);

    try (Connection conn = DBConnection.getConnection()) {
        String sql = "SELECT * FROM payment_transactions WHERE DATE(payment_date) = ? ORDER BY payment_date DESC";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, dateStr);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("id"),
                rs.getInt("item_id"),
                rs.getString("customer_name"),
                rs.getString("item_name"),
                rs.getDouble("payment_amount"),
                rs.getDouble("balance_after"),
                rs.getString("status"),
                rs.getTimestamp("payment_date"),
                "Delete"
            });
        }

        transactionTable.setModel(model);
        transactionTable.getColumn("Delete").setCellRenderer(new ButtonRenderer());
        transactionTable.getColumn("Delete").setCellEditor(new ButtonEditor(new JCheckBox()));

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Failed to filter transactions: " + e.getMessage());
    }


    }//GEN-LAST:event_searchbtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PaymentMonitoringForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PaymentMonitoringForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PaymentMonitoringForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PaymentMonitoringForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PaymentMonitoringForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backbtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton searchbtn;
    private com.toedter.calendar.JDateChooser searchdateChooser;
    private javax.swing.JTable transactionTable;
    // End of variables declaration//GEN-END:variables
}
