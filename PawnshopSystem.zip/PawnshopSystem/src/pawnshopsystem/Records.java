/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pawnshopsystem;
import java.awt.Color;
import java.awt.Component;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;


/**
 *
 * @author Acer
 */
public class Records extends javax.swing.JFrame {

   
    public JTable getTable() {
        return jTable2;  
    }
    /**
    
     */
    public Records() {
        initComponents();
         loadPawnItems("");
         initSearch();
}
    
    
    private void initSearch() {
        searchlbl.addMouseListener(new java.awt.event.MouseAdapter() {
        @Override
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            String keyword = searchtxt.getText().trim();
            loadPawnItems(keyword);
        }
    });
        
        searchtxt.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
        public void insertUpdate(javax.swing.event.DocumentEvent e) {
            updateSearch();
        }

        public void removeUpdate(javax.swing.event.DocumentEvent e) {
            updateSearch();
        }

        public void changedUpdate(javax.swing.event.DocumentEvent e) {
            updateSearch();
        }

        private void updateSearch() {
            String keyword = searchtxt.getText().trim();
            loadPawnItems(keyword);
        }
    });
    }
 
    

    
        public void loadPawnItems(String keyword) {
    try (Connection conn = DBConnection.getConnection()) {
        String sql;
        PreparedStatement pst;

        if (keyword == null || keyword.isEmpty()) {
           
            sql = "SELECT id, customer_name, item_name, description, pawn_value, pawn_date, due_date, status, balance FROM pawn_items";
            pst = conn.prepareStatement(sql);
        } else {
           
            sql = "SELECT id, customer_name, item_name, description, pawn_value, pawn_date, due_date, status, balance "
                + "FROM pawn_items "
                + "WHERE CAST(id AS CHAR) LIKE ? OR customer_name LIKE ? OR item_name LIKE ?";
            pst = conn.prepareStatement(sql);
            String searchPattern = "%" + keyword + "%";
            pst.setString(1, searchPattern);
            pst.setString(2, searchPattern);
            pst.setString(3, searchPattern);
        }

        ResultSet rs = pst.executeQuery();

        DefaultTableModel model = new DefaultTableModel(new String[]{
            "ID", "Customer Name", "Item Name", "Description", "Pawn Value", "Pawn Date", "Due Date", "Status", "Balance",
            "View", "Edit", "Delete"
        }, 0);

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("id"),
                rs.getString("customer_name"),
                rs.getString("item_name"),
                rs.getString("description"),
                rs.getDouble("pawn_value"),
                rs.getDate("pawn_date"),
                rs.getDate("due_date"),
                rs.getString("status"),
                rs.getDouble("balance"),
                "View", "Edit", "Delete"
            });
        }

        jTable2.setModel(model);
        jTable2.setRowHeight(35);
        
        int rowHeight = jTable2.getRowHeight();
int buttonWidth = rowHeight + 30; 


int[] columnWidths = { 50,150,150,200,100,100,100,100,100,buttonWidth,buttonWidth,buttonWidth };

for (int i = 0; i < columnWidths.length; i++) {
    if (i < jTable2.getColumnModel().getColumnCount()) {
        jTable2.getColumnModel().getColumn(i).setPreferredWidth(columnWidths[i]);
    }
}
        jTable2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        jTable2.getColumn("View").setCellRenderer(new ButtonRenderer());
        jTable2.getColumn("View").setCellEditor(new ButtonEditor(new JCheckBox(), jTable2));

        jTable2.getColumn("Edit").setCellRenderer(new ButtonRenderer());
        jTable2.getColumn("Edit").setCellEditor(new ButtonEditor(new JCheckBox(), jTable2));

        jTable2.getColumn("Delete").setCellRenderer(new ButtonRenderer());
        jTable2.getColumn("Delete").setCellEditor(new ButtonEditor(new JCheckBox(), jTable2));

        
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error loading data: " + ex.getMessage());
        ex.printStackTrace();
    }
}

    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }

       @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            setText((value == null) ? "" : value.toString());
            String label = (String) value;
            switch (label) {
                case "View": setBackground(Color.BLUE); break;
                case "Edit": setBackground(Color.GREEN); break;
                case "Delete": setBackground(Color.RED); break;
                default: setBackground(Color.GRAY); break;
            }
            setForeground(Color.WHITE);
            return this;
        }
    }

   
   class ButtonEditor extends DefaultCellEditor {
    protected JButton button;
    private String label;
    private boolean clicked;
    private int row;  
    private JTable table;  

    public ButtonEditor(JCheckBox checkBox, JTable table) {
        super(checkBox);
        this.table = table;
        button = new JButton();
        button.setOpaque(true);
        button.addActionListener(e -> {
            if (!clicked) return;
            if (row < 0 || row >= table.getRowCount()) {
                JOptionPane.showMessageDialog(Records.this, "Invalid row selection.");
                fireEditingStopped();
                return;
            }
           
            switch (label) {
                case "View":
                    showViewDialog(row);  
                    break;
                case "Edit":
                    openEditDialog(row);  
                    break;
                case "Delete":
                    deleteRecord(row);  
                    break;
                default:
                    break;
            }
            fireEditingStopped();
        });
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value,
            boolean isSelected, int row, int column) {
        this.row = row;  // Capture the row index here
        label = (value == null) ? "" : value.toString();
        button.setText(label);
        clicked = true;
        return button;
    }

    @Override
    public Object getCellEditorValue() {
        clicked = false;
        return label;
    }

    @Override
    public boolean stopCellEditing() {
        clicked = false;
        return super.stopCellEditing();
    }
}



    private void showViewDialog(int row) {
      try {
       
        int itemId = (int) jTable2.getValueAt(row, 0);
        String customerName = jTable2.getValueAt(row, 1).toString();
        String itemName = jTable2.getValueAt(row, 2).toString();
        String description = jTable2.getValueAt(row, 3).toString();
        String pawnValue = jTable2.getValueAt(row, 4).toString();
        String pawnDate = jTable2.getValueAt(row, 5).toString();
        String dueDate = jTable2.getValueAt(row, 6).toString();
        String status = jTable2.getValueAt(row, 7).toString();
        String balance = jTable2.getValueAt(row, 8).toString();

      
        String details = "Item ID: " + itemId +
                "\nCustomer Name: " + customerName +
                "\nItem Name: " + itemName +
                "\nDescription: " + description +
                "\nPawn Value: " + pawnValue +
                "\nPawn Date: " + pawnDate +
                "\nDue Date: " + dueDate +
                "\nStatus: " + status +
                "\nBalance: " + balance;

        
        int confirm = JOptionPane.showConfirmDialog(this, details + "\n\nDo you want to print this?", "View Record", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            
            String desktopPath = System.getProperty("user.home") + "/Desktop";
            String fileName = desktopPath + "/View_Receipt_Item_" + itemId + ".pdf";
           
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(fileName));
            document.open();

            document.add(new Paragraph("PAWNSHOP RECORD RECEIPT\n\n"));
            document.add(new Paragraph("Item ID: " + itemId));
            document.add(new Paragraph("Customer Name: " + customerName));
            document.add(new Paragraph("Item Name: " + itemName));
            document.add(new Paragraph("Description: " + description));
            document.add(new Paragraph("Pawn Value: " + pawnValue));
            document.add(new Paragraph("Pawn Date: " + pawnDate));
            document.add(new Paragraph("Due Date: " + dueDate));
            document.add(new Paragraph("Status: " + status));
            document.add(new Paragraph("Balance: " + balance));
            

            document.close();

            JTextArea textArea = new JTextArea(details);
            boolean printed = textArea.print();  
            if (!printed) {
        JOptionPane.showMessageDialog(this, "Print canceled or failed.");
    } else {
        JOptionPane.showMessageDialog(this, "Print Successfully");
    }
}  
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error generating/printing record: " + e.getMessage());
        e.printStackTrace();
    }
}
private void printRecordAsPDF(int row) {
    Document document = new Document();
    try {
        int id = (int) jTable2.getValueAt(row, 0);
        String fileName = "View_Record_Item_" + id + ".pdf";
        PdfWriter.getInstance(document, new java.io.FileOutputStream(fileName));
        document.open();

        document.add(new Paragraph("PAWNSHOP ITEM RECORD\n\n"));
        for (int i = 0; i < 9; i++) {
            String colName = jTable2.getColumnName(i);
            Object val = jTable2.getValueAt(row, i);
            document.add(new Paragraph(colName + ": " + val));
        }

        document.add(new Paragraph("\nRecord viewed and printed successfully."));

        document.close();

        int confirm = JOptionPane.showConfirmDialog(this,
            "Record PDF saved as:\n" + fileName + "\n\nWould you like to open it?",
            "Print Successful", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            java.awt.Desktop.getDesktop().open(new java.io.File(fileName));
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error printing record: " + e.getMessage());
        e.printStackTrace();
    }
}

    private void openEditDialog(int row) {
        try {
            int id = (int) jTable2.getValueAt(row, 0);
            String customerName = (String) jTable2.getValueAt(row, 1);
            String itemName = (String) jTable2.getValueAt(row, 2);
            String description = (String) jTable2.getValueAt(row, 3);
            double pawnValue = ((Number) jTable2.getValueAt(row, 4)).doubleValue();
            java.sql.Date pawnDate = (java.sql.Date) jTable2.getValueAt(row, 5);
            java.sql.Date dueDate = (java.sql.Date) jTable2.getValueAt(row, 6);
            String status = (String) jTable2.getValueAt(row, 7);
            double balance = ((Number) jTable2.getValueAt(row, 8)).doubleValue();

            UpdateItemForm dialog = new UpdateItemForm(this, true,
                    id, customerName, itemName, description,
                    pawnValue, pawnDate, dueDate, status, balance);

            dialog.setVisible(true);

            loadPawnItems(""); 

        } catch (ClassCastException ex) {
            JOptionPane.showMessageDialog(this, "Error reading data: " + ex.getMessage());
        }
    }

    private void deleteRecord(int row) {
        if (row < 0 || row >= jTable2.getRowCount()) {
            JOptionPane.showMessageDialog(this, "Invalid row selected.");
            return;
        }
        try {
            int id = (int) jTable2.getValueAt(row, 0);
            int confirm = JOptionPane.showConfirmDialog(this, "Delete record with ID " + id + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try (Connection conn = DBConnection.getConnection()) {
                    String sql = "DELETE FROM pawn_items WHERE id=?";
                    PreparedStatement pst = conn.prepareStatement(sql);
                    pst.setInt(1, id);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Record deleted.");
                    loadPawnItems(""); 
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Delete error: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
         
         

      
          

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        searchtxt = new javax.swing.JTextField();
        backbtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        searchlbl = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Gloucester MT Extra Condensed", 1, 36)); // NOI18N
        jLabel2.setText("ITEM RECORDS");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 10, -1, -1));

        searchtxt.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        getContentPane().add(searchtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 70, 330, 30));

        backbtn.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        backbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pawnshopsystem/balik.png"))); // NOI18N
        backbtn.setText("Back");
        backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbtnActionPerformed(evt);
            }
        });
        getContentPane().add(backbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 700, -1, -1));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(jTable2);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 1286, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 567, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, 1310, 550));

        searchlbl.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        searchlbl.setText("Search:");
        getContentPane().add(searchlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, 90, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pawnshopsystem/bgbg.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-4, 0, 1570, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbtnActionPerformed
    Dashboard dashboard = new Dashboard();
    dashboard.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_backbtnActionPerformed

     
            
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Records.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Records.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Records.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Records.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Records().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backbtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    public javax.swing.JTable jTable2;
    private javax.swing.JLabel searchlbl;
    private javax.swing.JTextField searchtxt;
    // End of variables declaration//GEN-END:variables
}
